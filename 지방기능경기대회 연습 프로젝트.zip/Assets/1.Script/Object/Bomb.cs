using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour
{
    public Rigidbody rig;
    public static Bomb bomb;
    [SerializeField] float speed;
    [SerializeField] GameObject axis;
    [SerializeField] GameObject BoomEffect;
    [SerializeField] GameObject BoomEffect2;
    private bool isAttack = true;

    private void Awake()
    {
        if (bomb == null)
            bomb = this;
        else
            Destroy(gameObject);
        rig = GetComponent<Rigidbody>();
    }
    void Update()
    {
        Boom();
    }

    void Boom()
    {
        axis.transform.Rotate(0, 0, 500 * Time.deltaTime);
        if (isAttack)
        {
            StartCoroutine(IsAttacking());
            isAttack = false;
        }
    }
    IEnumerator IsAttacking()
    {
        yield return new WaitForSecondsRealtime(0.1f);
        float t = 0f;
        while (t < 1)
        {
            t += Time.deltaTime;
            rig.useGravity = false;
            Move();
            yield return null;
        }
        rig.velocity = Vector3.zero;
        axis.SetActive(false);
        BoomEffect.SetActive(true);
        yield return new WaitForSecondsRealtime(0.2f);
        Instantiate(BoomEffect2,transform.position,Quaternion.identity);
        Monster[] monsters = FindObjectsOfType<Monster>();
        Bullet[] bullets = FindObjectsOfType<Bullet>();
        foreach (var item in monsters)
        {
            item.hp = 0;
        }
        foreach (var item in bullets)
        {
            if (item.bullets == Bullets.player)
                continue;
            Destroy(item.gameObject);
        }
        Camera.main.GetComponent<CameraShake>().SetUp(0.2f, 1.5f);
        yield return new WaitForSecondsRealtime(1f);
        Destroy(gameObject);
    }

    void Move()
    {

        Vector3 pos = transform.position;
        pos.z += 5;
        Quaternion targetRotation = Quaternion.LookRotation(pos - transform.position);
        axis.transform.rotation = Quaternion.Euler(targetRotation.x, targetRotation.y, axis.transform.eulerAngles.z);
        transform.position = Vector3.Lerp(transform.position, pos, speed * Time.deltaTime);
    }
}
