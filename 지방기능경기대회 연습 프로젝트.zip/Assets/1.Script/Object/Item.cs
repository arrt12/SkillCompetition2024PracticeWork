using System.Collections;
using System.Collections.Generic;
using UnityEngine;

enum Items
{
    invincibility,
    hp,
    fuel,
    attack
}
public class Item : MonoBehaviour
{
    [SerializeField] Items items;
    void Update()
    {
        Move();
        ItemDestory();
    }
    void Move()
    {
        transform.Translate(0, 0, -3 * Time.deltaTime);
    }
    void Invincibility()
    {
        Player.player.isInvincibilitying = true;
        print("����");
    }
    void Attack()
    {
        Player.player.LevelCount++;
        if (Player.player.LevelCount >= 3)
        {
            Player.player.LevelCount = 3;
        }
    }
    void Fuel()
    {
        Player.player.fuel += 300;
        if (Player.player.fuel >= 1000)
        {
            Player.player.fuel = 1000;
        }
    }
    void Hp()
    {
        Player.player.hp += 20;
        if (Player.player.hp >= 100)
        {
            Player.player.hp = 100;
        }
    }
    void ItemDestory()
    {
        var viewPos = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPos.x > 1.5f) Destroy(gameObject);
        if (viewPos.x < -0.5f) Destroy(gameObject);
        if (viewPos.y > 1.5f) Destroy(gameObject);
        if (viewPos.y < -0.5f) Destroy(gameObject);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            switch (items)
            {
                case Items.invincibility:
                    Invincibility();
                    break;
                case Items.hp:
                    Hp();
                    break;
                case Items.fuel:
                    Fuel();
                    break;
                case Items.attack:
                    Attack();
                    break;
            }
            Destroy(gameObject);
        }
    }
}
