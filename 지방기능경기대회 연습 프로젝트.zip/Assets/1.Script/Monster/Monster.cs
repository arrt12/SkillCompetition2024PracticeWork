using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Monsters
{
    monster1,//������ �̵��ϸ鼭 �÷��̾� �������� �����ϴ� ��
    monster2,//�� ������ ��
    monster3,// �������� ���� �ٴϴ� ��
    meteor
}
public class Monster : MonoBehaviour
{
    int count = 0;
    public float hp = 100;
    private bool isMeteor = true; 
    [SerializeField] float speed;
    [SerializeField] Monsters monsters;
    private float attackTime = 0;
    [SerializeField] GameObject bulletPrefab;
    [SerializeField] GameObject axis;
    [SerializeField] GameObject attackRang;
    [SerializeField] GameObject DeadEfact;
    [SerializeField] GameObject[] items;
    [SerializeField] Transform bulletSpawn;
    private bool hitIng = false;
    private bool isDead = false;
    private bool isDeadIng = false;

    void Start()
    {
        if (monsters != Monsters.meteor)
            return;
        Quaternion targetRotation = Quaternion.LookRotation(Player.player.transform.position - axis.transform.position);
        transform.rotation = targetRotation;
        //if ( monsters == Monsters.meteor)
        //    return;
        //float Rand = Random.Range(10,-10);
        //targetRotation.y += Rand;
        //transform.rotation = targetRotation;
    }
    void Update()
    {
        if (isDead)
            return;
        switch (monsters)
        {
            case Monsters.monster1:
                Monster1();
                MonsterMove();
                LookAt();
                break;
            case Monsters.monster2:
                Monster2();
                Rotate(new Vector3(0, 500 * Time.deltaTime, 0));
                MonsterMove();
                break;
            case Monsters.monster3:
                Monster3();
                LookAt();
                break;
            case Monsters.meteor:
                Meteor();
                Rotate(new Vector3(300 * Time.deltaTime, 0, 0));
                break;
        }
        Destroy(gameObject,15f);
        Dead();
    }
    void Monster1()
    {
        attackTime += Time.deltaTime;
        if (attackTime >= 1)
        {
            Instantiate(bulletPrefab, bulletSpawn.position, Quaternion.Euler(axis.transform.eulerAngles));
            attackTime = 0;
        }
    }
    void LookAt()
    { 
        Quaternion targetRotation = Quaternion.LookRotation(Player.player.transform.position - axis.transform.position);
        axis.transform.rotation = targetRotation;
    }
    void Monster2()
    {
        float axisPos = 0;
        attackTime += Time.deltaTime;
        if (attackTime >= 1.5f)
        {
            for (int i = 0; i < 10; i++)
            {
                Instantiate(bulletPrefab, transform.position, Quaternion.Euler(0, axisPos, 0));
                axisPos += 36;
            }
            attackTime = 0;
        }
    }
    void Monster3()
    {
        MonsterMove();
    }
    void MonsterMove()
    {
        transform.Translate(0, 0, -speed * Time.deltaTime);
    }
    void Meteor()
    {
        if (isMeteor)
        {
            StartCoroutine(MeteorAttack());
            isMeteor = false;
        }
    }
    IEnumerator MeteorAttack()
    {
        attackRang.SetActive(true);
        for (int i = 0; i < 10; i++)
        {
            attackRang.SetActive(true);
            yield return new WaitForSecondsRealtime(0.1f);
            attackRang.SetActive(false);
            yield return new WaitForSecondsRealtime(0.1f);
        }
        axis.SetActive(true);
        float t =0;
        while (t < 10)
        {
            t += Time.deltaTime;
            MonsterMove();
            yield return null;
        }
    }
    void Rotate(Vector3 vector)
    {
        axis.transform.Rotate(vector);
    }
    void Dead()
    {
        if (hp <=0)
        {
            isDead = true;
        }
        if (isDead && count <= 0)
        {
            StartCoroutine(Deading());
            isDead = false;
            isDeadIng = true;
            count++;
        }
    }
    IEnumerator Deading()
    {
        GameManager.gameManager.kills++;
        yield return null;
        axis.SetActive(false);
        Instantiate(DeadEfact, transform.position,Quaternion.identity);
        RandItem();
        Destroy(gameObject);
    }
    IEnumerator Hit(float hp)
    {
        if (!isDeadIng)
        {
            this.hp -= hp;
            hitIng = true;
            axis.SetActive(false);
            yield return new WaitForSecondsRealtime(0.1f);
            axis.SetActive(true);
            hitIng = false;
        }
    }
    void RandItem()
    {
        if (monsters == Monsters.meteor)
            return;
        int randValue = Random.Range(0,50);
        print(randValue);
        switch (randValue)
        {
            case 0:
                Instantiate(items[0], transform.position,Quaternion.identity);
                break;
            case 10:
                Instantiate(items[1], transform.position, Quaternion.identity);
                break;
            case 20:
                Instantiate(items[2], transform.position, Quaternion.identity);
                break;
            case 40:
                Instantiate(items[3], transform.position, Quaternion.identity);
                break;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (hitIng)
            return;
        if (isDeadIng)
            return;
        if (monsters == Monsters.meteor)
            return;
        if (other.gameObject.CompareTag("PlayerBt"))
        {
            StartCoroutine(Hit(30));
        }
    }
}
