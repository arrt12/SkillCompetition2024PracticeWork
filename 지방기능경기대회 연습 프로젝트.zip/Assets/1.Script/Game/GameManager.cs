using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Game
{
    start,
    gaming,
    midBoss,
    endBoss,
    end,
    Dead
}
public class GameManager : MonoBehaviour
{
    public Game game;
    public static GameManager gameManager;
    [SerializeField] GameObject midBoss;
    [SerializeField] GameObject EndBoss;
    public int kills = 0;
    public int BossKills = 0;
    public float GameeTime = 0;
    public int Score = 0;
    public float time = 0;
    int count;
    private bool isEnd  = false;
    public bool isGameEnd  = false;
    public bool isDead = false;

    private void Awake()
    {
        if (gameManager == null)
            gameManager = this;
        else
            Destroy(gameObject);
        Screen.SetResolution(1920, 1080, false);
    }

    private void Update()
    {
        Score = (((int)GameeTime * 10) + (BossKills * 100) + (kills * 10)) / 10;
        GameBool();
        if(!isGameEnd)
            GameeTime += Time.deltaTime;
    }

    void GameBool()
    {
        if (game == Game.gaming)
            time += Time.deltaTime;
        if (time >= 90 && count <=0 )
        {
            game = Game.midBoss;
            midBoss.SetActive(true);
            StageEnd();
            count++;
        }
        else if (time >= 180 && !isEnd)
        {
            game = Game.endBoss;
            EndBoss.SetActive(true);
            StageEnd();
            isEnd = true;
        }
    }

    void StageEnd()
    {
        Monster[] monsters = FindObjectsOfType<Monster>();
        SpawnManager[] spawnManagers = FindObjectsOfType<SpawnManager>();
        foreach (var item in monsters)
        {
            Destroy(item.gameObject);//�ı� ����Ʈ ��������� HP 0���� �ٲٱ�
        }
        foreach (var item in spawnManagers)
        {
            item.isBool = IsBool.isFalse;
        }
    }
}
