using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{ 
    public int LevelCount;
    private int DeadCount;
    public float hp = 100;
    public float fuel = 1000;
    public static Player player;
    [SerializeField] float speed;
    [SerializeField] Vector3 movePos;
    [SerializeField] GameObject axis;
    [SerializeField] private float limitXAngle;//ȸ���ϴ� ���� ���� ������ ��
    [SerializeField] float attackTime;
    [SerializeField] GameObject bulletPrefab;
    public GameObject ib;
    private float rotateSmoothDamp;
    private bool hitIng = false;
    public bool isInvincibility = false;
    public bool isInvincibilitying = false;
    private void Awake()
    {
        if (player == null)
            player = this;
        else
            Destroy(gameObject);
    }

    void Start()
    {
        LevelCount = 0;
    }

    void Update()
    {
        GetComponent<Rigidbody>().velocity = Vector3.zero;
        GetComponent<Rigidbody>().rotation = Quaternion.identity;
        transform.position = new Vector3(transform.position.x,0,transform.position.z);
        if (GameManager.gameManager.game == Game.start)
            return;
        if (isInvincibilitying)
        {
            StopCoroutine(Invincibilitying());
            StartCoroutine(Invincibilitying());//���� �ִ� ����
            isInvincibilitying = false;
        }
        if (GameManager.gameManager.isGameEnd == false)
            MoveInput();
        if (GameManager.gameManager.isGameEnd == false)
            Attack();
        Dead();
    }
    private void FixedUpdate()
    {
        if (GameManager.gameManager.isGameEnd)
        {
            axis.transform.rotation = Quaternion.identity;
            return;
        } 
        if (GameManager.gameManager.isGameEnd == false)
            Move();
        Player_Rotate(movePos.x);
    }
    void MoveInput()
    {
        movePos = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));

        var viewPos = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPos.x > 0.95f) viewPos.x = 0.95f;
        if (viewPos.x < 0.05f) viewPos.x = 0.05f;
        if (viewPos.y > 0.95f) viewPos.y = 0.95f;
        if (viewPos.y < 0.05f) viewPos.y = 0.05f;

        var translatePos = Camera.main.ViewportToWorldPoint(viewPos);

        transform.position = new Vector3(translatePos.x, transform.position.y, translatePos.z);
    }
    void Move()
    {
        transform.position += movePos * speed  * Time.deltaTime;
    }

    void Player_Rotate(float xAmount)
    {
        var rotateAmount = xAmount * limitXAngle;

        rotateAmount = Mathf.SmoothDampAngle(axis.transform.eulerAngles.z, rotateAmount, ref rotateSmoothDamp, 0.1f);

       axis.transform.rotation = Quaternion.Euler(axis.transform.eulerAngles.x, axis.transform.eulerAngles.y, rotateAmount);
    }
    void Attack()
    {
        Vector3 pos = transform.position;
        pos.z += 2;
        if (attackTime > 0)
        {
            attackTime -= Time.deltaTime;
        }
        else
        {
            if (Input.GetKey(KeyCode.X))
            {
                switch (LevelCount)
                {
                    case 0:
                        BulletSpawn(bulletPrefab, pos, 0, new Vector3(0, 0, 180));
                        break;
                    case 1:
                        BulletSpawn(bulletPrefab, pos, 0.5f, new Vector3(0, 0, 180));
                        BulletSpawn(bulletPrefab, pos, -0.5f, new Vector3(0, 0, 180));
                        break;
                    case 2:
                        BulletSpawn(bulletPrefab, pos, 1f, new Vector3(0, 10, 180));
                        BulletSpawn(bulletPrefab, pos, -1f, new Vector3(0, -10, 180));
                        BulletSpawn(bulletPrefab, pos, 0f, new Vector3(0, 0, 180));
                        break;
                    case 3:
                        BulletSpawn(bulletPrefab, pos, 1.2f, new Vector3(0, 10, 180));
                        BulletSpawn(bulletPrefab, pos, -1.2f, new Vector3(0, -10, 180));
                        BulletSpawn(bulletPrefab, pos, -0.5f, new Vector3(0, 0, 180));
                        BulletSpawn(bulletPrefab, pos, 0.5f, new Vector3(0, 0, 180));
                        break;
                }
                attackTime = 0.1f;
            }
        }
    }
    void BulletSpawn(GameObject gameObject , Vector3 spawntransform ,float a, Vector3 pos)
    {
        spawntransform.x += a;
        Instantiate(gameObject, spawntransform, Quaternion.Euler(pos));
    }
    IEnumerator Hit(float hp)
    {
        this.hp -= hp;
        hitIng = true;
        Camera.main.GetComponent<CameraShake>().SetUp(0.1f,1f);
        for (int i = 0; i < 7; i++)
        {
            axis.SetActive(false);
            yield return new WaitForSecondsRealtime(0.1f);
            axis.SetActive(true);
            yield return new WaitForSecondsRealtime(0.1f);
        }
        hitIng = false;
    }
    public IEnumerator Invincibilitying()
    {
        isInvincibility = true;
        for (int i = 0; i < 40; i++)
        {
            ib.SetActive(true);
            yield return new WaitForSecondsRealtime(0.05f);
            ib.SetActive(false);
            yield return new WaitForSecondsRealtime(0.05f);
        }
        isInvincibility = false;
    }
    void Dead()
    {
        if((hp <=0 || fuel <=0) && DeadCount <= 0)
        {
            Camera.main.GetComponent<CameraShake>().SetUp(0.2f,2f);
            GameManager.gameManager.isGameEnd = true;
            GameManager.gameManager.isDead = true;
            Monster[] monsters = FindObjectsOfType<Monster>();
            SpawnManager[] spawns = FindObjectsOfType<SpawnManager>();
            Bullet[] Bullet = FindObjectsOfType<Bullet>();
            foreach (var item in monsters)
            {
                Destroy(item.gameObject);
            }
            foreach (var item in Bullet)
            {
                Destroy(item.gameObject);
            }
            foreach (var item in spawns)
            {
                item.isBool = IsBool.isFalse;
            }
            if (MidBoss.midBoss != null)
                Destroy(MidBoss.midBoss.gameObject);
            if (EndBoss.endBoss != null)
                Destroy(EndBoss.endBoss.gameObject);
            GameManager.gameManager.game = Game.Dead;
            DeadCount++;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (hitIng)
            return;
        if (isInvincibility)
            return;
        if (other.gameObject.CompareTag("MosterBt"))
        {
            StartCoroutine(Hit(10));
            Destroy(other.gameObject);
        }
        if (other.gameObject.CompareTag("Moster"))
        {
            StartCoroutine(Hit(10));
        }
        if (other.gameObject.CompareTag("Mt"))
        {
            StartCoroutine(Hit(20));
        }
        if (other.gameObject.CompareTag("Boss"))
        {
            StartCoroutine(Hit(30));
        }
        if (other.gameObject.CompareTag("Pt3"))
        {
            StartCoroutine(Hit(30));
        }
        if (other.gameObject.CompareTag("Laser"))
        {
            StartCoroutine(Hit(30));
        }
    }
}
