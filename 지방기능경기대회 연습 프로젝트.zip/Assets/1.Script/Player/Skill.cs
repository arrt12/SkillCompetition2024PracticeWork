using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Skill : MonoBehaviour
{ 
    public static Skill skill;
    [SerializeField] GameObject bomb;
    [SerializeField] Image iSkill_1;
    [SerializeField] Image iSkill_2;
    public float SkillTime_1 = 20;
    public float SkillTime_2 = 30;

    private void Awake()
    {
        if (skill == null)
            skill = this;
        else
            Destroy(gameObject);
    }

    void Start()
    {
        SkillTime_1 = 20;
        SkillTime_2 = 30;
    }

    void Update()
    {
        if (GameManager.gameManager.game == Game.end)
            return;

        if (GameManager.gameManager.game == Game.start)
            return;

        if (SkillTime_1 <= 20)
        {
            SkillTime_1 += Time.deltaTime;
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Z))
            {
                Skill_1();
                SkillTime_1 = 0f;
            }
        }

        if (SkillTime_2 <= 30)
        {
            SkillTime_2 += Time.deltaTime;
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.C))
            {
                print("ü�� ȸ��");
                Skill_2();
                SkillTime_2 = 0f;
            }
        }
        SKill_UI();
    }
    void Skill_1()
    {
        Vector3 pos = transform.position;
        pos.y+= 1;
        Instantiate(bomb , transform.position, Quaternion.identity);
        Bomb.bomb.rig.AddForce(Vector3.up * 6 + Vector3.back * 2,ForceMode.Impulse);
    }
    
    void Skill_2()
    {
        Player.player.hp = 100;
    }
    
    void SKill_UI()
    {
        iSkill_1.fillAmount = SkillTime_1 / 20;
        iSkill_2.fillAmount = SkillTime_2 / 30;
    }
}
