using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cheat : MonoBehaviour
{
    void Update()
    {   if (GameManager.gameManager.game == Game.start)
            return;
        if (Input.GetKeyDown(KeyCode.F1))
        {
            F1();
        }
        if (Input.GetKeyDown(KeyCode.F2))
        {
            F2();
        }
        if (Input.GetKeyDown(KeyCode.F3))
        {
            F3();
        }
        if (Input.GetKeyDown(KeyCode.F4))
        {
            F4();
        }
        if (Input.GetKeyDown(KeyCode.F5))
        {
            F5();
        }
        if (Input.GetKeyDown(KeyCode.F6))
        {
            F6();
        }
    }

    void F1()
    {
        Monster[] monsters = FindObjectsOfType<Monster>();
        MidBoss midBoss = FindObjectOfType<MidBoss>();
        EndBoss endBoss = FindObjectOfType<EndBoss>();
        if(monsters != null)
            foreach (var item in monsters)
            {
                item.hp = 0;
            }
        if (midBoss != null)
            midBoss.hp = 0;
        if (endBoss != null)
            endBoss.hp = 0;
    }
    void F2()
    {
        Player.player.LevelCount = 3;
    }
    void F3()
    {
        Skill.skill.SkillTime_1 = 20;
        Skill.skill.SkillTime_2 = 30;
    }
    void F4()
    {
        Player.player.hp = 100;    
    }

    void F5()
    {
        Player.player.fuel = 1000;
    }
    void F6()
    {
        if (GameManager.gameManager.time < 90 && GameManager.gameManager.game == Game.gaming)
        {
            GameManager.gameManager.time = 90;
        }
        else if (GameManager.gameManager.time > 90 && GameManager.gameManager.time < 180 && GameManager.gameManager.game == Game.gaming)
        {
            GameManager.gameManager.time = 180;
        }

        if  (GameManager.gameManager.game == Game.midBoss)
        {
            MidBoss.midBoss.hp = 0;
        }
        else if (GameManager.gameManager.game == Game.endBoss)
        {
            EndBoss.endBoss.hp = 0;
        }
    }
}
